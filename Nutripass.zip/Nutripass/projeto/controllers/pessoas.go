package controllers

import (
	"nutripass-api/models"
	"nutripass-api/utils"
	"net/http"

	"github.com/gin-gonic/gin"
)

func Retorno(c *gin.Context) {
	// Validate input
	var input models.Pessoa
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}

	result := utils.FatorAtividade(input)

	c.JSON(http.StatusOK, gin.H{
		"data": result,
	})
}
