package models

type CreateAlimentoInput struct {

	Nomealimento   string  `json:"nomealimento"`
	Cho            float64 `json:"cho"`
	Ptn            float64 `json:"ptn"`
	Fat            float64 `json:"fat"`
}
