package models

type Pessoa struct {
	Nome           string  `json:"nome"`
	Peso           float64 `json:"peso"`
	Altura         float64 `json:"altura"`
	Idade          float64 `json:"idade"`
	Sexo           string  `json:"sexo"`
	Fatoratividade float64 `json:"fator"`
}
