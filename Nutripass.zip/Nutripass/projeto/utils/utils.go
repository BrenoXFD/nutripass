package utils

import (
	"nutripass-api/models"
	"fmt"
)

func CalcularTMB(p models.Pessoa) (resultTMB float64) {
	if p.Sexo == "masculino" {
		resultTMB = (66 + (13.7 * p.Peso) + (5 * p.Altura) - (6.8 * p.Idade))

	} else if p.Sexo == "feminino" {
		resultTMB = (655 + (9.6 * p.Peso) + (1.8 * p.Altura) - (4.7 * p.Idade))

	} else {
		fmt.Println("erro")

	}

	return

}

func FatorAtividade(p models.Pessoa) (resultTMBfinal float64) {
	tmb := CalcularTMB(p)
	if p.Fatoratividade < 1 {
		resultTMBfinal = tmb * 1.2

	} else if p.Fatoratividade >= 1 && p.Fatoratividade < 3 {
		resultTMBfinal = tmb * 1.375

	} else if p.Fatoratividade >= 3 && p.Fatoratividade < 5 {
		resultTMBfinal = tmb * 1.55

	} else if p.Fatoratividade >= 5 && p.Fatoratividade <= 6 {
		resultTMBfinal = tmb * 1.725

	} else {
		resultTMBfinal = tmb * 1.9

	}

	return
}
