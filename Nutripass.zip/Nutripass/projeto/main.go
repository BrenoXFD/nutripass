package main

import (
	"nutripass-api/controllers"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	r.POST("/nutripass", controllers.Retorno)

	r.Run()
}
